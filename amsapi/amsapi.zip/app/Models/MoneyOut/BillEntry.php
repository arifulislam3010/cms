<?php

namespace App\Models\MoneyOut;

use Illuminate\Database\Eloquent\Model;

class BillEntry extends Model
{
    //
}
