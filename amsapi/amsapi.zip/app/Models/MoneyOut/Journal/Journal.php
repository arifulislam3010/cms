<?php

namespace App\Models\MoneyOut\Journal;

use Illuminate\Database\Eloquent\Model;

class Journal extends Model
{
    //
}
