<?php

return [
    'name' => 'ResourceLanguage'
];
