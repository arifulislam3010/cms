<?php

return [
    'name' => 'ContentManager'
];
