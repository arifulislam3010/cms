<?php

return [
    'name' => 'Resource'
];
