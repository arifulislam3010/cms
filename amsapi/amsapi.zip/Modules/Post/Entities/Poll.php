<?php

namespace Modules\Post\Entities;
use Illuminate\Database\Eloquent\Model;

class Poll extends Model
{
    protected $table = "polls";
    protected $fillable = [];
}
