<?php

return [
    'name' => 'Post'
];
