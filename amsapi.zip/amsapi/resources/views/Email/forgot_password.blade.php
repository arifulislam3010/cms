
<h1>Reset Password</h1>
<p>
	For Reset Password Click Here
	<a href="http://admin.rubelgroup.com.bd/reset-password/{{$user->email}}/{{$code}}">Reset Password</a>
</p>
