<h1>Please activate your account</h1>
<p>
	For Activate Your Account Click Here
	<a href="http://amsapi.bemantech.com/api/activate/{{$user->email}}/{{$code}}">Activate Account</a>
</p>
