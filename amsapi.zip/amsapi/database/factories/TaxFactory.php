<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Account\Tax::class, function (Faker $faker) {
    return [
        //
    ];
});
