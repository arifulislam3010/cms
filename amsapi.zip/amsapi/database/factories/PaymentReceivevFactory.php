<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\PaymentReceivev::class, function (Faker $faker) {
    return [
        //
    ];
});
