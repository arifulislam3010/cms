<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Account\Bank::class, function (Faker $faker) {
    return [
        //
    ];
});
