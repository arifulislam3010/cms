<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\Invocie::class, function (Faker $faker) {
    return [
        //
    ];
});
