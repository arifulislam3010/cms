<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyOut\Journal\Journal::class, function (Faker $faker) {
    return [
        //
    ];
});
