<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\Income::class, function (Faker $faker) {
    return [
        //
    ];
});
