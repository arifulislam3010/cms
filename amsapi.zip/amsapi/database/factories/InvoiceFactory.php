<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\Invoice::class, function (Faker $faker) {
    return [
        //
    ];
});
