<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\PaymentReceive::class, function (Faker $faker) {
    return [
        //
    ];
});
