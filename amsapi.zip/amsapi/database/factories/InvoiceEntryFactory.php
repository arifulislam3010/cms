<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\InvoiceEntry::class, function (Faker $faker) {
    return [
        //
    ];
});
