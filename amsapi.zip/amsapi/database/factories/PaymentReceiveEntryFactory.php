<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\PaymentReceiveEntry::class, function (Faker $faker) {
    return [
        //
    ];
});
