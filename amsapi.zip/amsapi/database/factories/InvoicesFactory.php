<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\invoices::class, function (Faker $faker) {
    return [
        //
    ];
});
