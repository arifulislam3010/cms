<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyOut\BillEntry::class, function (Faker $faker) {
    return [
        //
    ];
});
