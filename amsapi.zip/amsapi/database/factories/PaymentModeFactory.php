<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Account\PaymentMode::class, function (Faker $faker) {
    return [
        //
    ];
});
