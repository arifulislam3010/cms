<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyIn\InvocieEntry::class, function (Faker $faker) {
    return [
        //
    ];
});
