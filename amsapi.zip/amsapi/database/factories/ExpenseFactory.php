<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyOut\Expense::class, function (Faker $faker) {
    return [
        //
    ];
});
