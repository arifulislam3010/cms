<?php

use Faker\Generator as Faker;

$factory->define(App\Models\MoneyOut\PaymentMade::class, function (Faker $faker) {
    return [
        //
    ];
});
