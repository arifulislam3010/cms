<?php

namespace App\Models\MoneyIn;

use Illuminate\Database\Eloquent\Model;

class InvoiceEntry extends Model
{
    //
}
