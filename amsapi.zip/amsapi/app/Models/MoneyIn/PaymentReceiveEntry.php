<?php

namespace App\Models\MoneyIn;

use Illuminate\Database\Eloquent\Model;

class PaymentReceiveEntry extends Model
{
    //
}
