<?php

namespace App\Models\MoneyOut\Journal;

use Illuminate\Database\Eloquent\Model;

class JournalEntry extends Model
{
    //
}
