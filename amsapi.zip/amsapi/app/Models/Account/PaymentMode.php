<?php

namespace App\Models\Account;

use Illuminate\Database\Eloquent\Model;

class PaymentMode extends Model
{
    //
}
