<?php

namespace App\Models\Journal;

use Illuminate\Database\Eloquent\Model;

class Journal extends Model
{
    //
}
