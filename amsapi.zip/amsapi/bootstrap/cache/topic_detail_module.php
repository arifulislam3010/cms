<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\TopicDetail\\Providers\\TopicDetailServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\TopicDetail\\Providers\\TopicDetailServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);