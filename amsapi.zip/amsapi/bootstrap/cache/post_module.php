<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Post\\Providers\\PostServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Post\\Providers\\PostServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);