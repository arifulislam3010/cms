<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ContentManager\\Providers\\ContentManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ContentManager\\Providers\\ContentManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);