<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ResourceLanguage\\Providers\\ResourceLanguageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ResourceLanguage\\Providers\\ResourceLanguageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);