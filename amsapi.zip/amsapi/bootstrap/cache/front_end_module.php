<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FrontEnd\\Providers\\FrontEndServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FrontEnd\\Providers\\FrontEndServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);