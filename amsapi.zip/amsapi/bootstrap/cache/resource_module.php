<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Resource\\Providers\\ResourceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Resource\\Providers\\ResourceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);