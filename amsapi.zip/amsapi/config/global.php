<?php 

return [
    'file_path' => 'http://localhost:8000/uploads/',
    'font_url' => 'http://localhost:8080/',
    'api_url' => 'http://localhost:8000/',
    'base_url'=> 'http://localhost:8088/',
];

?>