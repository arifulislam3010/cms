<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;



Route::post('/auth/login','RegisterLoginPasswordResetController@login');





