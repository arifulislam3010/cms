<?php

return [
    'name' => 'TopicDetail'
];
