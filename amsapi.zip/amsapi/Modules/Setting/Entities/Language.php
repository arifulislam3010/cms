<?php

namespace Modules\Setting\Entities;

use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    protected $table = "language";
    protected $fillable = [];
}
