<?php

return [
    'name' => 'Gallery'
];
