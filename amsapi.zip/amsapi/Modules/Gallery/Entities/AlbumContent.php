<?php

namespace Modules\Gallery\Entities;

use Illuminate\Database\Eloquent\Model;

class AlbumContent extends Model
{
    protected $fillable = [];

}
