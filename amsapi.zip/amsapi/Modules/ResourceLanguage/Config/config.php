<?php

return [
    'name' => 'ResourceLanguage'
];
