<?php

return [
    'name' => 'Resource'
];
