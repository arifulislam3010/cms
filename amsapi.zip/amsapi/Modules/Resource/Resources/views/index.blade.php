@extends('resource::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>
        This view is loaded from module: {!! config('resource.name') !!}
    </p>
<<<<<<< HEAD
@endsection
=======
@stop
>>>>>>> 9e75e65b875438f1859fa372d07440c5cda89fae
