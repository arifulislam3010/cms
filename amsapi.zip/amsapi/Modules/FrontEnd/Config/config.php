<?php

return [
    'name' => 'FrontEnd'
];
