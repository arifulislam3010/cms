<?php

namespace Modules\Post\Transformers;

use Illuminate\Http\Resources\Json\Resource;
use Modules\ContentManager\Entities\User ;
use Modules\ContentManager\Transformers\Image as ImageResource ;

use Modules\Setting\Transformers\Tag as TagResource ;
use Modules\Setting\Transformers\Topic as TopicResource ;
use Modules\Setting\Transformers\Category as CategoryResource ;
use Modules\Setting\Transformers\Area as AreaResource ;
use Modules\ContentManager\Entities\Content ;
use Modules\ContentManager\Transformers\Content as ContentResource ;
use Modules\Setting\Transformers\Scroll as ScrollResource; 
class PostDetail extends Resource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $temp = null ;
        
        $auto_share['flag'] = $this->auto_share_flag    ;
        $auto_share['time'] = $this->auto_share_date    ;
        $auto_share['caption'] = $this->auto_share_caption ;   


        return [
            'id' => $this->id,
            'shoulder' => $this->shoulder,
            'headline' => $this->headline,
            'hanger' => $this->hanger,
            'reporter' => User::where('id',$this->reporter_id)->first(),
            'author' => User::where('id',$this->author_id)->first(),
            'content' => $this->content,
            'featured_img' => new ContentResource (Content::where('id',$this->featured_image_id)->first()), 
            'featured_vid' => new ContentResource(Content::where('id',$this->featured_video_id)->first()), 
            'more_photo_arr' => ContentResource::collection($this->contents),
            'video_position' => $this->video_position ,
            'auto_share' => $auto_share ,
            'schedule_time' => $this->schedule_post_date ,
            'backdate_time' => $this->backdate_post_date ,
            'share_at' => $this->share_at,
            'publish_at' => $this->published_at,
            'status' => $this->status,
            'instant_article' => $this->instant_article,
            'news_tags' => TagResource::collection($this->tags),
            'selected_topics' => TopicResource::collection($this->topics),
            'selected_categories' => CategoryResource::collection($this->categories),
            'selected_scrolls' => ScrollResource::collection($this->scrolls),
            'selected_areas' => AreaResource::collection($this->areas),
            'selected_areas2' => AreaResource::collection($this->areas),

        ];
    }
}
