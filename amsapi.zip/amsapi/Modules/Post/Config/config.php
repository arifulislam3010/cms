<?php

return [
    'name' => 'Post'
];
