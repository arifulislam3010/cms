<?php

namespace Modules\ContentManager\Entities;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $fillable = [];
}
